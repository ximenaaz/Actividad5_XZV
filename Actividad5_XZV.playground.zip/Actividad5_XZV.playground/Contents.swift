import UIKit

class Persona {
    
    var estatura:Float;
    var edad:Int;
    
    var saludo:String = "";
    var caminar:Int = 0;
    
    init(estatura:Float, edad:Int){
        self.estatura = estatura
        self.edad = edad;
    }
    
    func Saludar(nombre:String) {
        self.saludo = nombre
    }
    
    func Caminar(pasos:Int){
        self.caminar = pasos;
    }
}
 
var person = Persona(estatura: 1.52, edad: 21);
person.Saludar(nombre: "Ximena Zenteno");
person.Caminar(pasos: 130);

print("Mi nombre es \(person.saludo), Mucho gusto");
print("\(person.saludo) camino \(person.caminar) pasos");
      
struct Pantalla {
    var ancho:Int;
    var alto:Int;
    
    init(ancho:Int, alto:Int)
    {
        self.ancho = ancho;
        self.alto = alto;
    }
    
    func Resolucion () -> (Int, Int){
        return(self.ancho , self.alto);
    }
}

var res = Pantalla(ancho: 40, alto: 20);


extension Int{
    var horas:Int{
        return self*3600
    }
}
60.horas;
extension String {
    var diaSemana:String{
        return self;
}

func numDia()-> String {
    switch self.diaSemana {
    case "Domingo":
        return "Domingo = Dia 1"
    case "Lunes":
        return "Lunes = Dia 2"
    case "Martes":
        return "Martes = Dia 3"
    case "Miercoles":
        return "Miercoles = Dia 4"
    case "Jueves":
        return "Jueves = Dia 5"
    case "Viernes":
        return "Viernes = Dia 6"
    case "Sabado":
        return "Sabado = Dia 7"
    default:
        return "Dia invalido"
    }
  }
}



var variableOpcional:Int;

let dias = ["CUN":120, "CDMX":200, "MTY":100, "OAX":300]
let variable:Int?

variable = dias["DF"];

if dias ["DF"] != nil
{
    print("Si existe")
}
else
{
    print("No existe")
}
